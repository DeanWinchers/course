import grpc
import mutex_pb2
import mutex_pb2_grpc
from threading import Lock
from concurrent import futures


class Mutex(mutex_pb2_grpc.MutexServicer):
    def __init__(self):
        super().__init__()
        self.seen_list = []
        self.mutex_owner = None
        self.add_lock = Lock()
        self.minus_lock = Lock()
        self.block_lock = Lock()
        self.block = False

    def give_mutex(self, request, context):
        self.add_lock.acquire()
        if request.clientID in self.seen_list:
            self.add_lock.release()
            return mutex_pb2.acquireResponse(
                mutex_info='Duplication detected, get mutex failed', mutex=0)
        print('Receive client {} acquire'.format(request.clientID))
        self.seen_list.append(request.clientID)
        self.block_lock.acquire(self.block)
        self.block = True
        self.mutex_owner = request.clientID
        print('client {} get the mutex'.format(request.clientID))
        self.add_lock.release()
        return mutex_pb2.acquireResponse(
            mutex_info='Get mutex successfully', mutex=1)

    def release_mutex(self, request, context):
        print('Client {} release mutex'.format(request.clientID))
        self.minus_lock.acquire()
        if self.mutex_owner == request.clientID:
            self.mutex_owner = None
            self.block = False
            self.block_lock.release()
            self.minus_lock.release()
            return mutex_pb2.releaseResponse(
                mutex_info='Release mutex successfully')
        else:
            self.minus_lock.release()
            return mutex_pb2.releaseResponse(mutex_info='Release mutex failed')


def run_server():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    mutex_pb2_grpc.add_MutexServicer_to_server(Mutex(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    server.wait_for_termination()


if __name__ == '__main__':
    run_server()