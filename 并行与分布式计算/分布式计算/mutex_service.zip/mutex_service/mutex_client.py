import grpc
import mutex_pb2
import mutex_pb2_grpc
import time
import argparse
import random
import threading


class Client(object):
    def __init__(self, clientID):
        super().__init__()
        self.clientID = clientID
        self.mutex_ = 0
        self.channel = grpc.insecure_channel('localhost:50051')
        self.stub = mutex_pb2_grpc.MutexStub(self.channel)
        self.lock = threading.Lock()

    def get_mutex(self):
        response = self.stub.give_mutex(
            mutex_pb2.acquireRequest(clientID=self.clientID))
        print(response.mutex_info)
        self.mutex_ += response.mutex

    def release_mutex(self):
        response = self.stub.release_mutex(
            mutex_pb2.releaseRequest(clientID=self.clientID))
        print(response.mutex_info)
        self.mutex_ = 0

    def run_client(self):
        self.lock.acquire()
        self.get_mutex()
        if self.mutex_:
            print('Do something')
            time.sleep(20)
            self.release_mutex()
        self.lock.release()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-i",
                        "--id",
                        help="set a clientID (default:Random).",
                        type=int,
                        default=-1)
    parser.add_argument("-t",
                        "--thread",
                        help="set the number of threads (default:1).",
                        type=int,
                        default=1)
    args = parser.parse_args()
    clientID = args.id if args.id != -1 else random.randint(1, 1000)
    thread_num = args.thread
    client = Client(clientID)
    for i in range(thread_num):
        t = threading.Thread(target=client.run_client)
        t.start()