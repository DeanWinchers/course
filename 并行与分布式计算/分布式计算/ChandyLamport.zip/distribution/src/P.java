import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class P extends Thread{
	private Message message;
	private int state = 0;
	private GlobalState globalState;
	private boolean mark = true;
	public P(Message m, GlobalState s)
	{
		this.message = m;
		this.globalState = s;
	}
	public void run() {
		
		try {
			ServerSocket serverSocket = new ServerSocket(8888);
			while(true)
			{	
				Socket socket;
				String str;
				//Thread.sleep(1000);
				//P send message to Q
				socket = new Socket("localhost",7777);
				OutputStream outToServer = socket.getOutputStream();
				DataOutputStream out = new DataOutputStream(outToServer);
				out.writeUTF(message.getMessage());
				System.out.println("P sent message: " + message.getMessage());
				//send M to Q
				if(state == 101)
				{
					globalState.state = state;
					globalState.channel.setMessage("null");
					out.writeBoolean(mark);
				}
				socket.close();
				
				//P receive message from Q
				socket = serverSocket.accept();
				DataInputStream in = new DataInputStream(socket.getInputStream());
				str = in.readUTF();
				System.out.println("P received message: " + str + " state: " + state);
				state++;
				//wait for M from Q
				if(in.available() != 0)
				{
					globalState.channel.setMessage(str);
					socket.close();
					return;
				}
				socket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
