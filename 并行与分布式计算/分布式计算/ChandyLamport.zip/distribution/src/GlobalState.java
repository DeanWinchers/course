
public class GlobalState {
	int state;
	Message channel;
	public GlobalState() 
	{
		state = 0;
		channel = new Message("null");
	}
}
