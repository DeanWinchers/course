
public class Channel {
	private Message message;
	public Channel(Message m)
	{
		this.message = m;
	}
}
