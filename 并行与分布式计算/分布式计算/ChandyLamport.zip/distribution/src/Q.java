import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Q extends Thread{
	private Message message;
	private int state = 0;
	private GlobalState globalState;
	private boolean mark = true;
	private boolean flag = false;
	public Q(Message m, GlobalState s)
	{
		this.message = m;
		this.globalState = s;
	}
	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(7777);
			while(true)
			{
				Socket socket;
				String str;
				//Q receive message from P
				socket = serverSocket.accept();
				DataInputStream in = new DataInputStream(socket.getInputStream());
				str = in.readUTF();
				System.out.println("Q received message: " + str);
				state++;
				//wait for M from P
				if(in.available() != 0)
				{
					globalState.state = state;
					globalState.channel.setMessage("null");
					flag = true;
				}
				socket.close();
				
				//Thread.sleep(2000);
				//Q send message to P
				socket = new Socket("localhost",8888);
				OutputStream outToServer = socket.getOutputStream();
				DataOutputStream out = new DataOutputStream(outToServer);
				out.writeUTF(message.getMessage());
				System.out.println("Q sent message: " + message.getMessage());
				if(flag)
				{
					out.writeBoolean(mark);
					socket.close();
					return;
				}
				socket.close();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
