import java.util.Queue;

public class ChandyLamport {
	static public Message m = new Message("Hello");
	static public GlobalState pState = new GlobalState();
	static public GlobalState qState = new GlobalState();
	public static void main(String[] args) {
		P p = new P(m, pState);
		Q q = new Q(m, qState);
		p.start();
		q.start();
		while(true)
		{
			if(!q.isAlive() && !p.isAlive())
			{
				System.out.println("The global state is:");
				System.out.println("P state is: " + pState.state + ", P's channel is: " + pState.channel.getMessage());
				System.out.println("Q state is: " + qState.state + ", Q's channel is: " + qState.channel.getMessage());
				return;
			}
		}
	}
}
